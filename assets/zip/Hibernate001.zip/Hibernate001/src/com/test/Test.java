package com.test;

import com.example.Student;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;

public class Test {

    public static void main(String[] args) {

        // 加载 Hibernate 核心配置文件
        Configuration configuration = new Configuration();
        configuration.configure();

        // 创建 SessionFactory 对象
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // 使用 SessionFactory 创建 session 对象
        Session session = sessionFactory.openSession();

        // 开启事务
        Transaction transaction = session.beginTransaction();

        // 具体 crud 操作
        Student student = new Student();
        student.setName("张三三");
        student.setSex("男");
        student.setAddress("北京市朝阳区");
        student.setPassword("123456");

        // 提交事务
        session.save(student);
        transaction.commit();

        // 关闭资源
        session.close();
        sessionFactory.close();
    }
}
